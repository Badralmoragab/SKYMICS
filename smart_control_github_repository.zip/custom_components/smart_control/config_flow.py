"""Config flow for Smart Control Integration."""
from homeassistant import config_entries
import voluptuous as vol

DOMAIN = "smart_control"

class SmartControlConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle a config flow for Smart Control System."""
    VERSION = 1

    async def async_step_user(self, user_input=None):
        """Handle the initial step."""
        if self._async_current_entries():
            return self.async_abort(reason="single_instance_allowed")

        if user_input is not None:
            return self.async_create_entry(title="Smart Control System", data={})

        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema({})
        )
